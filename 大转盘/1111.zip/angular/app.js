var angular=require('angular');

require('angular-resource');

var app=angular.module('app',['ngResource']);

module.exports=app;


